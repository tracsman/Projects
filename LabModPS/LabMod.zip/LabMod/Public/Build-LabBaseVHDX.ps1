function Build-LabBaseVHDX{
    <#
    .SYNOPSIS
        Creates a base Hyper-V VM for building a gold-image VHDX.

    .DESCRIPTION
        Creates a Generation 2 Hyper-V VM with the specified OS ISO attached, configured
        with standard lab settings (4 vCPU, 4-8 GB dynamic memory, VLAN 7). After the VM
        is created, follow the README instructions to complete the OS install and sysprep
        the image into a reusable base VHDX.

    .PARAMETER OS
        The operating system to build. Valid values are "Server2025" and "Ubuntu".
        Defaults to "Server2025".

    .EXAMPLE
        Build-LabBaseVHDX

        Creates a Server 2025 base VM using the default ISO path.

    .EXAMPLE
        Build-LabBaseVHDX -OS Ubuntu

        Creates an Ubuntu base VM using the default ISO path.
    #>

    [CmdletBinding()]
    param (
        [Parameter(ValueFromPipeline = $true, HelpMessage = 'Enter OS')]
        [ValidateSet("Server2025", "Ubuntu")]
        [string]$OS="Server2025")

    switch ($OS) {
        "Server2025" {
            $VMName = "Base2025"
            $ISO = "C:\Hyper-V\ISO\Microsoft\26100.1742.240906-0331.ge_release_svc_refresh_SERVER_EVAL_x64FRE_en-us.iso"
        }
        "Ubuntu" {
            $VMName = "BaseUbuntu"
            $ISO = "C:\Hyper-V\ISO\Linux\ubuntu-24.04.3-live-server-amd64.iso"
        }
    }
    $VMConfig = "C:\Hyper-V\Config"
    $VHDDest = "C:\Hyper-V\Virtual Hard Disks\"
    $VMDisk = $VHDDest + $VMName + ".vhdx"

    $StartTime = Get-Date
    Write-Log "Creating $OS Base VM" -TimeStamp
    $VM = New-VM -Name $VMName -NewVHDPath $VMDisk -NewVHDSizeBytes 128000000000 -Path $VMConfig -MemoryStartupBytes 4GB -Generation 2
    Set-VM -VM $VM -SnapshotFileLocation $VMConfig -SmartPagingFilePath $VMConfig
    Add-VMScsiController -VMName $VMName
    Set-VMProcessor -VM $VM -Count 4
    Set-VMMemory -VM $VM -DynamicMemoryEnabled $True -MaximumBytes 8GB -MinimumBytes 4GB -StartupBytes 4GB
    Remove-VMNetworkAdapter -VM $VM
    Add-VMNetworkAdapter -VM $VM -Name "PublicNIC" -SwitchName "vs-NIC3" 
    $VMNic = Get-VMNetworkAdapter -VM $VM
    Set-VMNetworkAdapterVlan -VMNetworkAdapter $VMNic -Access -VlanId 7 -ErrorAction Stop
    Enable-VMIntegrationService -VMName $VMName -Name "Guest Service Interface"
    Add-VMDvdDrive -VMName $VMName -Path $ISO
    $MyDVD = Get-VMDvdDrive -VMName $VMName
    switch ($OS) {
        "Server2025" {Set-VMFirmware -VMName $VMName -EnableSecureBoot On -FirstBootDevice $MyDVD}
        default {Set-VMFirmware -VMName $VMName -SecureBootTemplate "MicrosoftUEFICertificateAuthority" -FirstBootDevice $MyDVD}
    }
    Write-Log "VM Build complete!" -TimeStamp
    Write-Host
    Write-Log "Follow the instructions at https://github.com/tracsman/Projects/blob/master/LabModPS/README.md to completed the build of the base VHDX file."
    Write-Host
    
    $EndTime = Get-Date
    $TimeDiff = New-TimeSpan $StartTime $EndTime
    $RunTime = $TimeDiff.ToString('hh\:mm\:ss')
    Write-Log "VM build completed successfully" -TimeStamp
    Write-Log "Time to create: $RunTime"
    Write-Host
}
