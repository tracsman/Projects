function New-LabVM {
    <#
    .SYNOPSIS
        This command creates a new VM object, of the requested operating system, and configures it for use in the physical
        Pathfinder lab, including network configuration and appropriate username and password for this tenant.

    .DESCRIPTION
        This command creates a new VM object, of the requested operating system, and configures it for use in the physical
        Pathfinder lab, including network configuration and appropriate username and password for this tenant.

    .PARAMETER TenantID
        This parameter is required and is the two digit tenant ID in the lab. Valid values are from 10 to 99 inclusive.

    .PARAMETER Subscription
        This optional parameter signifies the Azure subscription in which the tenant resource group has already been created.
        Valid values are "ExpressRoute-Lab" and "Pathfinder", the default value is "ExpressRoute-Lab".

    .PARAMETER OS
        This optional parameter signifies the requested operating system for the VM. Valid values are "Server2025"
        and "Ubuntu", the default value is "Server2025".

    .PARAMETER VMNumber
        Optional tenant-wide VM sequence number (1 to 99), independent of the target server and OS.
        If omitted, the next available VM number on this server is used.

    .PARAMETER CopyOnly
        This optional parameter instructs this command to only create the new VM VHDX, and doesn't configure it for use or
        start the VM.

    .PARAMETER VMCreateOnly
        This optional parameter instructs this command to only create the VM object in hypervisor. The VHDX must already 
        exist. This option will not and doesn't configure it for use or start the VM.

    .PARAMETER PostBuildOnly
        This optional parameter instructs this command to only apply the post build config (updating network settings, VM
        Name and User accounts). The VM Object must already exist and be running.

    .PARAMETER PwdUpdateOnly
        This optional parameter instructs this command to only update the PathLabUser password from the Azure Key Value.
        The VM must already exist and be running.

    .EXAMPLE
        New-LabVM 16

        This command creates a VM for tenant 16. The subscription and OS would default to "ExpressRoute-Lab" and 
        "Server2025" respectively

    .EXAMPLE
        New-LabVM -TenantID 16 -OS "Ubuntu"

        This command creates a VM for tenant 16. The OS is specifically called out to override the
        default value.

    .LINK
        https://github.com/tracsman/ERPath/tree/master/Team/Jon/LabPSModule

    .NOTES
        With VMNumber, the suffix follows the tenant's requested VM order across all physical servers and OS types.
        Creating an explicitly numbered VM fails if that VM exists on the target host, or copying its disk would
        overwrite an existing disk. Without VMNumber, numbering retains the next-free behavior on this server.

    #>

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, HelpMessage = 'Enter Company ID')]
        [ValidateRange(10, 99)]
        [int]$TenantID,
        [ValidateSet("Server2025", "Ubuntu")]
        [string]$OS="Server2025",
        [ValidateRange(1, 99)]
        [int]$VMNumber,
        [switch]$CopyOnly = $false,
        [switch]$VMCreateOnly = $false,
        [switch]$PostBuildOnly = $false,
        [switch]$PwdUpdateOnly = $false,

        [Parameter(Mandatory = $false, HelpMessage = 'Optional server admin credential. If omitted, prompt interactively.')]
        [System.Management.Automation.PSCredential]$AdminCred,

        [Parameter(Mandatory = $false, HelpMessage = 'Optional environment user credential. If omitted, prompt interactively.')]
        [System.Management.Automation.PSCredential]$UserCred)

    #
    # Create On Prem VM Execution Path
    # 1. Initialize
    # 2. Validate
    # 3. Copy VHDX
    # 4. Create VM Object
    # 5a. Do post-deploy build
    # or
    # 5b. Do Password Update
    # 6. End nicely

    # 1. Initialize
    $StartTime = Get-Date

    # Lab Environment Variables
    $Lab = ($env:COMPUTERNAME.Split("-"))[0]
    if ($PSBoundParameters.ContainsKey('VMNumber')) {
        $VMName = '{0}-ER-{1}-VM{2:00}' -f $Lab, $TenantID, $VMNumber
    }
    else {
        [int]$VMInstance = 0
        Do {
            $VMInstance++
            $VMName = $Lab + "-ER-" + $TenantID + "-VM" + $VMInstance.ToString("00")
        } Until ((Get-VM -Name "$VMName*").Count -eq 0)
    }
    Switch ($OS) {
        'Server2025' {$BaseVHDName = "Base2025.vhdx"}
        'Ubuntu' {$BaseVHDName = "BaseUbuntu.vhdx"}
    }
    $VHDSource = "C:\Hyper-V\ISO\BaseVHDX\" + $BaseVHDName
    $VMConfig = "C:\Hyper-V\Config"
    $VHDDest = "C:\Hyper-V\Virtual Hard Disks\"
    $VMDisk = $VHDDest + $VMName + ".vhdx"  
    $VM_UserName = "PathLabUser"

    # Script Variables
    If (-not $CopyOnly -and -not $VMCreateOnly -and -not $PostBuildOnly -and -not $PwdUpdateOnly) {
        $CopyOnly = $true
        $VMCreateOnly = $true
        $PostBuildOnly = $true
        $Action = "Building VM"
    }
    ElseIf ($CopyOnly) {$Action = "Coping VM drive"}
    ElseIf ($VMCreateOnly) {$Action = "Creating VM (no post build)"}
    ElseIf ($PostBuildOnly ) {$Action = "Post build script deployment"}
    ElseIf ($PwdUpdateOnly) {$Action = "Updating VM password"}
   
    # 2. Validate
    # Admin Session Check
    if (-not (Assert-LabAdminContext -WarnOnly)) {
        Return
    }

    if ($PSBoundParameters.ContainsKey('VMNumber')) {
        if ($VMCreateOnly -and @(Get-VM -ErrorAction Stop | Where-Object Name -eq $VMName).Count -gt 0) {
            throw "VM '$VMName' already exists on $env:COMPUTERNAME. Remove or reconcile the existing tenant deployment before retrying."
        }
        if ($CopyOnly -and (Test-Path -LiteralPath $VMDisk -ErrorAction Stop)) {
            throw "Disk '$VMDisk' already exists. Refusing to overwrite an existing tenant VM disk."
        }
    }

    If (-not (Test-Path $VHDSource)) { Write-Host; Write-Warning "Base .VHDX file ($BaseVHDName) not found"; Write-Host; Return }

    # Get admin creds
    Write-Log "  Grabbing admin secrets"
    if (-not $AdminCred) {
        $AdminCred = Get-Credential -UserName "Administrator" -Message "Enter server Administrator (Server-Admin) password for PathLab"
    }
    if (-not $UserCred) {
        $UserCred = Get-Credential -UserName $VM_UserName -Message "Enter server Key vault password for company $TenantID"
    }
    $Users = @($UserCred.UserName, $($UserCred.GetNetworkCredential().Password))

    # Send the starting info
    Write-Log "$Action..." -TimeStamp
    Write-Log "          Lab: $Lab"
    Write-Log "    Tenant ID: $TenantID"
    Write-Log "       VMName: $VMName"
    Write-Log "           OS: $OS"
   
    # 3. Copy VHDX
    If ($CopyOnly) {
        Write-Log "Copying VHD for Tenant $TenantID" -TimeStamp
        New-LabVMDrive -from $VHDSource -to $VMDisk
    }

    # 4. Create VM Object
    If ($VMCreateOnly) {
        Write-Log "Creating VM" -TimeStamp
        $VLAN = $TenantID
        $VM = New-VM -Name $VMName -VHDPath $VMDisk -Path $VMConfig -MemoryStartupBytes 4GB -Generation 2
        Set-VM -VM $VM -SnapshotFileLocation $VMConfig -SmartPagingFilePath $VMConfig
        Add-VMScsiController -VMName $VMName
        Set-VMProcessor -VM $VM -Count 4
        Set-VMMemory -VM $VM -DynamicMemoryEnabled $True -MaximumBytes 8GB -MinimumBytes 4GB -StartupBytes 4GB
        Remove-VMNetworkAdapter -VM $VM
        Add-VMNetworkAdapter -VM $VM -Name "PublicNIC" -SwitchName "vs-NIC3" 
        $VMNic = Get-VMNetworkAdapter -VM $VM
        Set-VMNetworkAdapterVlan -VMNetworkAdapter $VMNic -Access -VlanId $VLAN -ErrorAction Stop
        Enable-VMIntegrationService -VMName $VMName -Name "Guest Service Interface"
    }

    # 5a. Do post-deploy build
    If ($PostBuildOnly) {
        Switch ($OS) {
            "Server2025" {
                Write-Log "Starting VM" -TimeStamp
                Start-VM -Name $VMName
                Wait-VM -Name $VMName -For Heartbeat
                Write-Log "Pushing post deploy config" -TimeStamp

                If ((Invoke-Command -VMName $VMName -Credential $AdminCred { "Administrator" } -ErrorAction SilentlyContinue) -ne "Administrator") {
                    Write-Log "  Waiting for VM to come online: "
                }
                While ((Invoke-Command -VMName $VMName -Credential $AdminCred { "Administrator" } -ErrorAction SilentlyContinue) -ne "Administrator") {
                    Write-Host "*" -NoNewline
                    Start-Sleep -Seconds 1
                }
                Write-Log "  VM online, pushing post deploy config"
                Invoke-Command -VMName $VMName -Credential $AdminCred -ScriptBlock {
                    param ($VMName, $TenantID, $Users)

                    If (($VMName.Split("-"))[0] -eq "SEA") { $SecondOctet = 1 } Else { $SecondOctet = 2 }
                    If (($VMName.Split("-"))[0] -eq "SEA") { $IPv6Prefix = "2001:5a0:4406" } Else { $IPv6Prefix = "2001:5a0:3c06"}
                    [int]$VMHostIP = 9 + $VMName.Substring($VMName.Length - 2)
                    $VMIPv4 = "10." + $SecondOctet + "." + $TenantID + "." + $VMHostIP
                    $VMGWv4 = "10." + $SecondOctet + "." + $TenantID + ".1"
                    $VMIPv6 = $IPv6Prefix + ":" + $TenantID + "::" + $VMHostIP
                    $VMGWv6 = $IPv6Prefix + ":" + $TenantID + "::1"

                    $nicv4 = Get-NetIPAddress -AddressFamily IPv4 -AddressState Preferred -InterfaceAlias "Ethernet*"
                    If ($nicv4.IPv4Address -eq $VMIPv4) {"IPv4 address already set, skipping"}
                    Else {New-NetIPAddress -InterfaceIndex $nicv4.InterfaceIndex -IPAddress $VMIPv4 -PrefixLength 25 -DefaultGateway $VMGWv4 | Out-Null
                          Set-DnsClientServerAddress -InterfaceIndex $nicv4.InterfaceIndex -ServerAddresses "1.1.1.1", "1.0.0.1" | Out-Null}

                    $nicv6 = Get-NetIPAddress -AddressFamily IPv6 -AddressState Preferred -InterfaceAlias "Ethernet*"
                    If ($nicv6.IPv6Address -eq $VMIPv6) {"IPv6 address already set, skipping"}
                    Else {New-NetIPAddress -InterfaceIndex $nicv6.InterfaceIndex -IPAddress $VMIPv6 -PrefixLength 64 -DefaultGateway $VMGWv6 | Out-Null
                          Set-DnsClientServerAddress -InterfaceIndex $nicv6.InterfaceIndex -ServerAddresses "2606:4700:4700::1111", "2606:4700:4700::1001" | Out-Null}

                    # Turn on remote access and open firewall for it
                    Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server" -Name "fDenyTSConnections" -Value 0
                    Enable-NetFirewallRule -DisplayGroup "Remote Desktop"

                    # Turn On ICMPv4
                    Write-Host "  Opening ICMPv4 Port"
                    Try {Get-NetFirewallRule -Name Allow_ICMPv4_in -ErrorAction Stop | Out-Null
                        Write-Host "    Port already open"}
                    Catch {New-NetFirewallRule -DisplayName "Allow ICMPv4" -Name Allow_ICMPv4_in -Action Allow -Enabled True -Profile Any -Protocol ICMPv4 | Out-Null
                        Write-Host "    Port opened"}

                    # Turn On ICMPv6
                    Write-Host "  Opening ICMPv6 Port"
                    Try {Get-NetFirewallRule -Name Allow_ICMPv6_in -ErrorAction Stop | Out-Null
                        Write-Host "    Port already open"}
                    Catch {New-NetFirewallRule -DisplayName "Allow ICMPv6" -Name Allow_ICMPv6_in -Action Allow -Enabled True -Profile Any -Protocol ICMPv6 | Out-Null
                        Write-Host "    Port opened"}

                    # Get usernames and passwords
                    $VM_UserName = $Users[0]
                    $VM_UserPass = ConvertTo-SecureString $Users[1] -AsPlainText -Force 

                    # Create Local Accounts and add to Admin group
                    New-LocalUser -Name $VM_UserName -Password $VM_UserPass -FullName $VM_UserName -AccountNeverExpires -PasswordNeverExpires | Out-Null
                    Add-LocalGroupMember -Group "Administrators" -Member $VM_UserName

                    # Rename and restart
                    Rename-Computer -NewName "$VMName" -Restart

                } -ArgumentList $VMName, $TenantID, (,$Users)
            }
            "Ubuntu" {
                If (($VMName.Split("-"))[0] -eq "SEA") { $SecondOctet = 1 } Else { $SecondOctet = 2 }
                If (($VMName.Split("-"))[0] -eq "SEA") { $IPv6Prefix = "2001:5a0:4406" } Else { $IPv6Prefix = "2001:5a0:3c06"}
                [int]$VMHostIP = 9 + $VMName.Substring($VMName.Length - 2)
                $VMIPv4 = "10." + $SecondOctet + "." + $TenantID + "." + $VMHostIP
                $VMGWv4 = "10." + $SecondOctet + "." + $TenantID + ".1"
                $VMIPv6 = $IPv6Prefix + ":" + $TenantID + "::" + $VMHostIP
                $VMGWv6 = $IPv6Prefix + ":" + $TenantID + "::1"

                Write-Log "Pushing post deploy config" -TimeStamp
                
                Write-Log "  Updating SecureBootTemplate"
                Set-VMFirmware -VMName $VMName -SecureBootTemplate "MicrosoftUEFICertificateAuthority"

                Write-Log "  Starting VM"
                Start-VM -Name $VMName
                Wait-VM -Name $VMName -For IPAddress
                Start-Sleep 10

                Write-Log "  Creating startup script"
                mkdir "$env:TEMP\LabMod\" -Force | Out-Null
                Out-File "$env:TEMP\LabMod\TenantScriptNeeded.txt" -Force -NoNewline -Encoding ascii
                
                $VM_UserName = $Users[0]
                $VM_UserPass = $Users[1]
                
                $VM_UserName+":"+$VM_UserPass | Out-File "$env:TEMP\LabMod\temp.txt" -Force -NoNewline -Encoding ascii
                #$script  = "cp /etc/netplan/00-installer-config.yaml /etc/netplan/00-installer-config.yaml.bak`n"
                $script  = "cp /etc/netplan/50-cloud-init.yaml /etc/netplan/50-cloud-init.yaml.bak`n"
                $script += "sed -i 's/10.1.7.46/$VMIPv4/g' /etc/netplan/50-cloud-init.yaml`n"
                $script += "sed -i 's/10.1.7.1/$VMGWv4/g' /etc/netplan/50-cloud-init.yaml`n"
                $script += "sed -i '/routes:/a\ \ \ \ \ \ - to: ::\/0\n\ \ \ \ \ \ \ \ via: $VMGWv6' /etc/netplan/50-cloud-init.yaml`n"
                #$script += "sed -i '/eth0:/,/addresses:/ s/addresses:/addresses:\n\ \ \ \ \ \ - $VMIPv6\/64' /etc/netplan/50-cloud-init.yaml`n"
                $script += "sed -i '/eth0:/,/^[[:space:]]\{6\}addresses:/ s/^[[:space:]]\{6\}addresses:/      addresses:\n      - $VMIPv6\/64/' /etc/netplan/50-cloud-init.yaml`n"
                $script += "sed -i '/nameservers:/,/addresses:/ s/addresses:/addresses:\n\ \ \ \ \ \ \ \ - 2606:4700:4700::1111\n\ \ \ \ \ \ \ \ - 2606:4700:4700::1001/' /etc/netplan/50-cloud-init.yaml`n"
                $script += "netplan --debug generate`n"
				$script += "netplan apply`n"
                $script += "hostnamectl set-hostname $VMName`n"
                $script += "/usr/sbin/useradd -m $VM_UserName`n"
                $script += "cat /var/tmp/LabMod/temp.txt | /usr/sbin/chpasswd`n"
                $script += "/usr/sbin/usermod -aG sudo $VM_UserName`n"
                $script += "rm /var/tmp/LabMod/temp.txt -f`n"
                $script | Out-File "$env:TEMP\LabMod\tenant-update.sh" -Force -NoNewline -Encoding ascii

                Write-Log "  Copying startup scripts"
                Start-Sleep 10
                Copy-VMFile -Name $VMName -SourcePath "$env:TEMP\LabMod\temp.txt" -DestinationPath '/var/tmp/LabMod' -FileSource Host -Force
                Copy-VMFile -Name $VMName -SourcePath "$env:TEMP\LabMod\tenant-update.sh" -DestinationPath '/var/tmp/LabMod/' -FileSource Host -Force
                Copy-VMFile -Name $VMName -SourcePath "$env:TEMP\LabMod\TenantScriptNeeded.txt" -DestinationPath '/var/tmp/LabMod/' -FileSource Host -Force

                Write-Log "  Rebooting to kick off scripts"
                Write-Log "  Waiting on VM..."
                Stop-VM -Name $VMName
                Start-VM -Name $VMName
                Wait-VM -Name $VMName -For IPAddress
                Start-Sleep 20
                # Write-Log "  Rebooting to instantiate new settings"
                # Write-Log "  Waiting on VM..."
                # Stop-VM -Name $VMName
                # Start-VM -Name $VMName
                # Wait-VM -Name $VMName -For IPAddress
                # Start-Sleep 20
            }
        }
    }

    # 5b. Do Password Update
    If ($PwdUpdateOnly) {
        Write-Log "Updating Lab VM Passwords" -TimeStamp
        If ((Invoke-Command -VMName $VMName -Credential $AdminCred { "Administrator" } -ErrorAction SilentlyContinue) -ne "Administrator") {
            Write-Log "  Waiting for VM to come online..."
        }
        While ((Invoke-Command -VMName $VMName -Credential $AdminCred { "Administrator" } -ErrorAction SilentlyContinue) -ne "Administrator") {
            Write-Host "*" -NoNewline
            Start-Sleep -Seconds 1
        }
        Write-Log " VM online, pushing password updates"
        Invoke-Command -VMName $VMName -Credential $AdminCred -ScriptBlock {
            param ($Users)

            # Get usernames and passwords
            $VM_UserName = $Users[0]
            $VM_UserPass = ConvertTo-SecureString $Users[1] -AsPlainText -Force 

            # Update Local Accounts and add to Admin group
            Set-LocalUser -Name $VM_UserName -Password $VM_UserPass | Out-Null

        } -ArgumentList (,$Users)
    }

    # 6. End nicely
    $EndTime = Get-Date
    $TimeDiff = New-TimeSpan $StartTime $EndTime
    $RunTime = $TimeDiff.ToString('hh\:mm\:ss')
    Write-Log "$Action completed successfully" -TimeStamp
    Write-Log "Time to create: $RunTime" -TimeStamp
    Write-Host
}
